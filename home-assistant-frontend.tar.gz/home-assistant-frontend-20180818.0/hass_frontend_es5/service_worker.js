importScripts("/frontend_es5/precache-manifest.b49982b98bc054688bee7e33754276a5.js", "/frontend_es5/workbox-v3.3.0/workbox-sw.js");
workbox.setConfig({modulePathPrefix: "/frontend_es5/workbox-v3.3.0"});
/* global importScripts */
importScripts('/static/service-worker-hass.js');

