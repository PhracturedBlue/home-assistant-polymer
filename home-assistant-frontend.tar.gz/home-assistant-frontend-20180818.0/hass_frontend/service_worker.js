importScripts("/frontend_latest/precache-manifest.e0093a3dbae8be99d3196e19a02272d1.js", "/frontend_latest/workbox-v3.3.0/workbox-sw.js");
workbox.setConfig({modulePathPrefix: "/frontend_latest/workbox-v3.3.0"});
/* global importScripts */
importScripts('/static/service-worker-hass.js');

