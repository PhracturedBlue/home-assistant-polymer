(window.webpackJsonp=window.webpackJsonp||[]).push([[17],{613:function(e,s,t){"use strict";t.r(s);var a=t(0),r=t(3);t(172),customElements.define("ha-panel-kiosk",class extends r.a{static get template(){return a["a"]`
    <partial-cards
      id='kiosk-states'
      hass='[[hass]]'
      show-menu
      route='[[route]]'
      panel-visible
    ></partial-cards>
    `}static get properties(){return{hass:Object,route:Object}}})}}]);
//# sourceMappingURL=d0b457a0d9089c69938e.chunk.js.map